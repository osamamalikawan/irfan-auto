"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import AddLocationModal from "./AddLocationModal";
import { useMe } from "./Me";
import Toast from "./Toast";
import { Loading } from "./Loading";
import PaymentMethodsSetting from "./PaymentMethodsSetting";
import ThemeSetting from "./ThemeSetting";

type ListRow = { id: string; name: string; visible: boolean; products: number; is_market: boolean };
type LocRow = { id: string; name: string; type: string; racks: number; active: boolean };

export default function SettingsView() {
  const { can } = useMe();
  const [lists, setLists] = useState<ListRow[] | null>(null);
  const [locs, setLocs] = useState<LocRow[] | null>(null);
  const [error, setError] = useState("");
  const [addLoc, setAddLoc] = useState(false);
  const [toast, setToast] = useState("");
  const [negStock, setNegStock] = useState(false);
  const [red, setRed] = useState("70");
  const [green, setGreen] = useState("100");

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { setNegStock(!!j.settings?.allow_negative_stock); if (j.settings?.thresholds) { setRed(String(j.settings.thresholds.red)); setGreen(String(j.settings.thresholds.green)); } }).catch(() => {});
  }, []);
  async function toggleNeg(v: boolean) {
    setNegStock(v);
    const r = await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ allow_negative_stock: v }) });
    if (!r.ok) { setNegStock(!v); const j = await r.json().catch(() => ({})); setToast(j.error || "Could not save"); }
  }
  async function saveThresholds() {
    const r = await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ thresholds: { red: Number(red), green: Number(green) } }) });
    const j = await r.json().catch(() => ({}));
    setToast(r.ok ? "Target colours saved" : j.error || "Could not save");
  }
  async function move(i: number, dir: -1 | 1) {
    if (!locs) return;
    const k = i + dir;
    if (k < 0 || k >= locs.length) return;
    const next = [...locs];
    [next[i], next[k]] = [next[k], next[i]];
    setLocs(next);
    const r = await fetch("/api/inventory/locations/priority", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids: next.map((l) => l.id) }) });
    if (!r.ok) { setToast("Could not save the order"); loadLocs(); }
  }

  const loadLists = useCallback(async () => {
    const r = await fetch("/api/inventory/lists");
    const j = await r.json();
    if (!r.ok) return setError(j.error || "Could not load lists");
    setLists(j.lists);
  }, []);
  const loadLocs = useCallback(async () => {
    const r = await fetch("/api/inventory/locations");
    const j = await r.json();
    if (!r.ok) return setError(j.error || "Could not load locations");
    setLocs(j.locations);
  }, []);
  useEffect(() => { loadLists(); loadLocs(); }, [loadLists, loadLocs]);

  async function setMarket(id: string, is_market: boolean) {
    const before = lists;
    setLists((ls) => ls && ls.map((l) => (l.id === id ? { ...l, is_market } : l)));
    const r = await fetch("/api/inventory/lists", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, is_market }) });
    if (!r.ok) { setLists(before); const j = await r.json().catch(() => ({})); setToast(j.error || "Could not save"); }
  }
  async function setVisible(body: { id?: string; all?: boolean; visible: boolean }) {
    const before = lists;
    setLists((ls) => ls && ls.map((l) => (body.all || l.id === body.id ? { ...l, visible: body.visible } : l)));
    const r = await fetch("/api/inventory/lists", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!r.ok) {
      setLists(before);
      const j = await r.json().catch(() => ({}));
      setToast(j.error || "Could not save");
    }
  }

  const hidden = lists?.filter((l) => !l.visible).length ?? 0;

  return (
    <div>
      <header className="sticky top-0 z-20 border-b border-line bg-bg px-3 pb-2 pt-[calc(env(safe-area-inset-top)+0.5rem)] lg:hidden">
        <h1 className="text-lg font-bold">Settings</h1>
      </header>

      <div className="space-y-4 p-3 lg:max-w-3xl lg:p-5">
        {error && <p className="rounded-lg bg-red-bg p-2 text-sm text-red">{error}</p>}

        <section className="card divide-y divide-line">
          {[["/discounts", "Discounts", "Brand discounts and customer deals"], ["/promises", "Customer promises", "Who promised to pay, and when"], ["/market", "Market purchases", "Parts bought from the market for invoices"]].map(([href, t, sub]) => (
            <Link key={href} href={href} className="flex items-center justify-between p-4 active:opacity-70"><span><span className="block font-semibold">{t}</span><span className="text-sm text-muted">{sub}</span></span><span aria-hidden>›</span></Link>
          ))}
        </section>

        {can("users.manage") && (
          <Link href="/users" className="card flex items-center justify-between p-4 active:opacity-70">
            <span><span className="block font-semibold">Users &amp; Roles</span><span className="text-sm text-muted">Who can sign in and what they can do</span></span>
            <span aria-hidden>›</span>
          </Link>
        )}

        <section className="card p-4">
          <h2 className="mb-1 font-semibold">Appearance</h2>
          <p className="mb-3 text-sm text-muted">Choose how the app looks. This is saved on this device only.</p>
          <ThemeSetting />
        </section>

        <section className="card p-4">
          <h2 className="mb-1 font-semibold">Payment methods</h2>
          <p className="mb-3 text-sm text-muted">Shown when you take payment on a sale or collect money. Hide a method to remove it from those screens; old payments keep their method.</p>
          <PaymentMethodsSetting />
        </section>

        <section id="stock-settings" className="card scroll-mt-16 p-4">
          <div className="mb-1 flex items-center justify-between gap-2">
            <h2 className="font-semibold">Price lists</h2>
            <div className="flex gap-2">
              <button className="btn min-h-9 px-3" onClick={() => setVisible({ all: true, visible: true })} disabled={!lists || !hidden}>Show all</button>
              <button className="btn min-h-9 px-3" onClick={() => setVisible({ all: true, visible: false })} disabled={!lists || hidden === lists.length}>Hide all</button>
            </div>
          </div>
          <p className="mb-2 text-sm text-muted">
            Choose which lists appear on the Stock screen. Hidden lists are only left out of view; nothing is deleted.
            {lists ? " " + hidden + " of " + lists.length + " hidden." : ""}
          </p>
          {!lists && !error && <Loading />}
          <ul className="divide-y divide-line">
            {lists?.map((l) => (
              <li key={l.id} className="flex min-h-14 items-center gap-3 py-2">
                <div className="min-w-0 flex-1">
                  <p className={"break-words font-medium " + (l.visible ? "" : "text-muted")}>{l.name}</p>
                  <p className="text-xs text-muted">{l.products.toLocaleString()} products</p>
                </div>
                <label className="flex shrink-0 items-center gap-2 text-sm" title="Parts in a market list are bought from the market when sold">
                  <input type="checkbox" className="size-5" checked={l.is_market} onChange={(e) => setMarket(l.id, e.target.checked)} />Market list
                </label>
                <Link href={"/lists/" + l.id} className="btn min-h-9 px-3">Open</Link>
                <button role="switch" aria-checked={l.visible} aria-label={(l.visible ? "Hide " : "Show ") + l.name}
                  onClick={() => setVisible({ id: l.id, visible: !l.visible })}
                  className={"relative h-8 w-14 shrink-0 rounded-full transition-colors " + (l.visible ? "bg-accent" : "bg-line")}>
                  <span className={"absolute top-1 size-6 rounded-full bg-white shadow transition-all " + (l.visible ? "left-7" : "left-1")} />
                </button>
              </li>
            ))}
          </ul>
          {lists && !lists.length && <p className="py-3 text-sm text-muted">No lists yet. They appear after the product import.</p>}
        </section>

        <section className="card p-4">
          <h2 className="mb-1 font-semibold">Selling</h2>
          <label className="flex min-h-12 items-center gap-3">
            <input type="checkbox" className="size-5" checked={negStock} onChange={(e) => toggleNeg(e.target.checked)} />
            <span><span className="block">Allow selling more than is in stock</span><span className="block text-xs text-muted">Stock can go below zero. Leave off to refuse such invoices.</span></span>
          </label>
        </section>

        <section className="card p-4">
          <h2 className="mb-1 font-semibold">Target colours</h2>
          <p className="mb-2 text-sm text-muted">Used on the Sales Team and Dashboard bars: red below the first number, green from the second, amber in between (percent of target).</p>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label" htmlFor="th-red">Red below (%)</label><input id="th-red" className="input" type="number" inputMode="numeric" min="1" max="99" value={red} onChange={(e) => setRed(e.target.value)} /></div>
            <div><label className="label" htmlFor="th-green">Green from (%)</label><input id="th-green" className="input" type="number" inputMode="numeric" min="2" max="200" value={green} onChange={(e) => setGreen(e.target.value)} /></div>
          </div>
          <button className="btn mt-3" onClick={saveThresholds}>Save colours</button>
        </section>

        <section className="card p-4">
          <div className="mb-2 flex items-center justify-between gap-2">
            <h2 className="font-semibold">Stock locations</h2>
            {can("stock.manage") && <button className="btn btn-primary min-h-9 px-3" onClick={() => setAddLoc(true)}>Add stock location</button>}
          </div>
          <p className="mb-1 text-sm text-muted">Invoices take stock from the top location first, then the next. Use the arrows to change the order.</p>
          {!locs && !error && <Loading />}
          <ul className="divide-y divide-line">
            {locs?.map((l, i) => (
              <li key={l.id} className="flex items-center gap-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{l.name}</p>
                  <p className="text-xs text-muted">{l.type} · {l.racks} {l.racks === 1 ? "rack" : "racks"}</p>
                </div>
                <button className="btn size-10 min-h-10 px-0" disabled={i === 0} onClick={() => move(i, -1)} aria-label={"Sell from " + l.name + " earlier"}>↑</button>
                <button className="btn size-10 min-h-10 px-0" disabled={i === (locs?.length ?? 0) - 1} onClick={() => move(i, 1)} aria-label={"Sell from " + l.name + " later"}>↓</button>
              </li>
            ))}
          </ul>
          {locs && !locs.length && <p className="py-3 text-sm text-muted">No locations yet.</p>}
        </section>
      </div>

      {addLoc && <AddLocationModal onClose={() => setAddLoc(false)} onDone={(n) => { setAddLoc(false); setToast(n + " added"); loadLocs(); }} />}
      {toast && <Toast msg={toast} onHide={() => setToast("")} />}
    </div>
  );
}
